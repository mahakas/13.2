from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[3]
load_dotenv(BASE_DIR / ".env")

from backend_v2.providers.adapters.anthropic import AnthropicAdapter
from backend_v2.providers.adapters.gemini import GeminiAdapter
from backend_v2.providers.adapters.openai_compatible import OpenAICompatibleAdapter
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.contracts import ModelProfile
from backend_v2.core.enums import Capability


@dataclass(frozen=True, slots=True)
class ProviderConfig:
    name: str
    api_key_env: str
    base_url_env: str | None = None
    chat_model_env: str | None = None
    embedding_model_env: str | None = None
    vision_model_env: str | None = None
    default_base_url: str | None = None
    default_chat_model: str | None = None
    default_embedding_model: str | None = None
    default_vision_model: str | None = None


def build_external_registry_from_env() -> ProviderRegistry:
    """Register configured real providers without requiring any secret in source code."""
    registry = ProviderRegistry()
    configs = [
        ProviderConfig("openai", "OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_CHAT_MODEL", "OPENAI_EMBEDDING_MODEL", "OPENAI_VISION_MODEL", "https://api.openai.com/v1", "gpt-4o-mini", "text-embedding-3-small", "gpt-4o"),
        ProviderConfig("openrouter", "OPENROUTER_API_KEY", "OPENROUTER_BASE_URL", "OPENROUTER_CHAT_MODEL", "OPENROUTER_EMBEDDING_MODEL", "OPENROUTER_VISION_MODEL", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini", None, "openai/gpt-4o"),
        ProviderConfig("nvidia", "NVIDIA_API_KEY", "NVIDIA_BASE_URL", "NVIDIA_CHAT_MODEL", "NVIDIA_EMBEDDING_MODEL", "NVIDIA_VISION_MODEL", "https://integrate.api.nvidia.com/v1", "meta/llama-3.1-8b-instruct", None, None),
        ProviderConfig("qwen", "QWEN_API_KEY", "QWEN_BASE_URL", "QWEN_CHAT_MODEL", "QWEN_EMBEDDING_MODEL", "QWEN_VISION_MODEL", None, "qwen-plus", None, None),
        ProviderConfig("custom", "CUSTOM_LLM_API_KEY", "CUSTOM_LLM_BASE_URL", "CUSTOM_LLM_MODEL", "CUSTOM_EMBEDDING_MODEL", "CUSTOM_VISION_MODEL", None, None, None, None),
    ]

    external_priority = int(os.getenv("PROVIDER_DEFAULT_PRIORITY", "10"))

    for cfg in configs:
        api_key = os.getenv(cfg.api_key_env, "")
        base_url = os.getenv(cfg.base_url_env or "", cfg.default_base_url or "") if (cfg.base_url_env or cfg.default_base_url) else ""
        chat_model = os.getenv(cfg.chat_model_env or "", cfg.default_chat_model or cfg.name) if (cfg.chat_model_env or cfg.default_chat_model) else cfg.name
        embedding_model = os.getenv(cfg.embedding_model_env or "", cfg.default_embedding_model or "") if (cfg.embedding_model_env or cfg.default_embedding_model) else ""
        vision_model = os.getenv(cfg.vision_model_env or "", cfg.default_vision_model or "") if (cfg.vision_model_env or cfg.default_vision_model) else ""
        if not api_key or not base_url:
            continue
        adapter = OpenAICompatibleAdapter(
            cfg.name,
            api_key,
            base_url=base_url,
            default_model=chat_model,
            vision_models={vision_model} if vision_model else set(),
            timeout_seconds=float(os.getenv("PROVIDER_TIMEOUT_SECONDS", "60")),
        )
        models = [ModelProfile(model=chat_model, capabilities=frozenset({Capability.CHAT, Capability.STRUCTURED_OUTPUT}))]
        if embedding_model:
            models.append(ModelProfile(model=embedding_model, capabilities=frozenset({Capability.EMBEDDING})))
        if vision_model:
            models.append(ModelProfile(model=vision_model, capabilities=frozenset({Capability.CHAT, Capability.VISION, Capability.STRUCTURED_OUTPUT})))
        registry.register(adapter, priority=int(os.getenv(f"PROVIDER_PRIORITY_{cfg.name.upper()}", str(external_priority))), models=tuple(models))

    anthropic_key = os.getenv("ANTHROPIC_API_KEY", "")
    if anthropic_key:
        model = os.getenv("ANTHROPIC_CHAT_MODEL", "claude-3-5-sonnet-latest")
        adapter = AnthropicAdapter(anthropic_key, default_model=model, timeout_seconds=float(os.getenv("PROVIDER_TIMEOUT_SECONDS", "60")))
        registry.register(adapter, priority=int(os.getenv("PROVIDER_PRIORITY_ANTHROPIC", str(external_priority))), models=(ModelProfile(model=model, capabilities=frozenset({Capability.CHAT, Capability.VISION, Capability.STRUCTURED_OUTPUT})),))

    gemini_key = os.getenv("GEMINI_API_KEY", "") or os.getenv("GOOGLE_API_KEY", "")
    if gemini_key:
        model = os.getenv("GEMINI_CHAT_MODEL", "gemini-2.5-flash")
        adapter = GeminiAdapter(gemini_key, default_model=model)
        registry.register(adapter, models=(ModelProfile(model=model, capabilities=frozenset({Capability.CHAT, Capability.VISION, Capability.EMBEDDING, Capability.STRUCTURED_OUTPUT})),))

    return registry

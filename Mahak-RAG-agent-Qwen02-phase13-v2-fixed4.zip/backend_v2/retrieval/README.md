# Phase 6 — Retrieval

The retrieval layer now provides:

- `RetrievalScope` for grade/subject/course/chapter/lesson filtering.
- `RetrievalService` for query embedding → vector search → reranking → thresholding.
- `HybridReranker` combining vector relevance with lexical overlap.
- deterministic `InMemoryVectorStore` for local tests/development.
- source-aware citation construction from retrieval metadata.

The service is backend-agnostic through the `VectorStore` contract and uses the existing capability-based `EmbeddingService`.

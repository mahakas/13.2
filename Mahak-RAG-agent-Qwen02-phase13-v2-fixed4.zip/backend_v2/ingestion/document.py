from __future__ import annotations

from dataclasses import dataclass, field

from backend_v2.core.enums import Capability, SourceType


@dataclass(frozen=True, slots=True)
class SourceLocation:
    page: int | None = None
    start_time: float | None = None
    end_time: float | None = None
    url: str | None = None


@dataclass(frozen=True, slots=True)
class ExtractedDocument:
    source_type: SourceType
    text: str
    title: str
    metadata: dict = field(default_factory=dict)
    locations: tuple[SourceLocation, ...] = ()
    requires: frozenset[Capability] = field(default_factory=frozenset)


@dataclass(frozen=True, slots=True)
class ContentChunk:
    chunk_id: str
    text: str
    index: int
    metadata: dict = field(default_factory=dict)
    location: SourceLocation | None = None

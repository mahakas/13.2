# Mahak AI v2 — Phase 10

Phase 10 connects conversation-scoped uploads to retrieval and educational chat.

## New flow

```text
Session Upload
  -> Analyzer / Loader / Chunker
  -> SessionIndexService
  -> Embedding
  -> VectorStore collection: mahak_sessions
  -> Educational Retrieval
  -> Context Builder / LLM
  -> Source-aware Citation
```

## Session isolation

Session chunks are stored with both `source_id` and `session_file_id`. Retrieval supports:

- `source_ids` for source-level filtering
- `session_file_ids` for conversation-file filtering

Educational chat uses `session_file_ids`, so a file from another conversation cannot leak into the current conversation.

## Runtime

`backend_v2.runtime.runtime` owns the process-local provider/vector runtime used by the current V2 API. This removes the previous behavior where each chat request created a fresh empty vector store.

The runtime uses deterministic mock providers for development/tests. Real provider adapters will replace these without changing the retrieval contract.

## Phase 10 API behavior

`POST /api/uploads/session` now returns `indexed_chunks`.

`POST /api/chat/educational` can retrieve from:

1. permanent educational collection: `mahak_knowledge`
2. conversation-scoped session collection: `mahak_sessions`

Results are merged, ranked, and returned with source-aware citations.

## Current limitation

The default runtime is process-local and uses the deterministic in-memory VectorStore. Persistent Chroma/vector-store runtime wiring will be hardened in a later phase.

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from backend_v2.core.enums import Capability


@dataclass(frozen=True, slots=True)
class ProviderRequest:
    capability: Capability
    model: str
    payload: Any
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ProviderResponse:
    output: Any
    provider: str
    model: str
    latency_ms: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ModelProfile:
    model: str
    capabilities: frozenset[Capability]
    priority: int = 100
    quality_score: float = 1.0
    latency_score: float = 1.0
    cost_score: float = 1.0
    enabled: bool = True

    def supports(self, capability: Capability) -> bool:
        return self.enabled and capability in self.capabilities


@dataclass(frozen=True, slots=True)
class ProviderProfile:
    name: str
    models: tuple[ModelProfile, ...]
    priority: int = 100
    enabled: bool = True

    def candidates(self, capability: Capability) -> tuple[ModelProfile, ...]:
        return tuple(model for model in self.models if model.supports(capability))


class ProviderAdapter(Protocol):
    provider_name: str

    def supports(self, capability: Capability) -> bool: ...

    def execute(self, request: ProviderRequest) -> ProviderResponse: ...

    def health_check(self, capability: Capability | None = None) -> bool: ...

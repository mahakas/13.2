from __future__ import annotations

from typing import Any

from backend_v2.core.enums import Capability
from backend_v2.providers.contracts import ProviderRequest, ProviderResponse

try:
    from google import genai
    from google.genai import types
except Exception:  # pragma: no cover
    genai = None
    types = None


class GeminiAdapter:
    def __init__(self, api_key: str, *, default_model: str = "gemini-2.5-flash") -> None:
        self.provider_name = "gemini"
        self.api_key = api_key
        self.default_model = default_model
        self._client = genai.Client(api_key=api_key) if genai and api_key else None

    def supports(self, capability: Capability) -> bool:
        return capability in {Capability.CHAT, Capability.VISION, Capability.STRUCTURED_OUTPUT, Capability.EMBEDDING}

    @staticmethod
    def _to_parts(content: Any) -> list[Any]:
        if isinstance(content, str):
            return [content]
        parts: list[Any] = []
        for item in content or []:
            if not isinstance(item, dict):
                parts.append(str(item))
                continue
            kind = item.get("type")
            if kind == "text":
                parts.append(item.get("text", ""))
            elif kind == "image_url" and types is not None:
                image_url = item.get("image_url") or {}
                url = image_url.get("url", "") if isinstance(image_url, dict) else str(image_url)
                if url.startswith("data:"):
                    header, encoded = url.split(",", 1)
                    mime = header.split(";", 1)[0].split(":", 1)[-1]
                    import base64
                    parts.append(types.Part.from_bytes(data=base64.b64decode(encoded), mime_type=mime))
                elif url:
                    parts.append(types.Part.from_uri(file_uri=url, mime_type="image/jpeg"))
        return parts or [str(content)]

    def execute(self, request: ProviderRequest) -> ProviderResponse:
        if self._client is None:
            raise RuntimeError("Gemini provider is not configured")
        payload = request.payload if isinstance(request.payload, dict) else {"messages": request.payload}
        if request.capability is Capability.EMBEDDING:
            texts = payload.get("texts", [])
            result = self._client.models.embed_content(model=request.model, contents=texts)
            vectors = [item.values for item in getattr(result, "embeddings", [])]
            return ProviderResponse(vectors, self.provider_name, request.model)

        contents = []
        for message in payload.get("messages", []):
            role = "user" if message.get("role") != "assistant" else "model"
            contents.append({"role": role, "parts": self._to_parts(message.get("content", ""))})
        result = self._client.models.generate_content(model=request.model, contents=contents)
        return ProviderResponse(getattr(result, "text", ""), self.provider_name, request.model)

    def health_check(self, capability: Capability | None = None) -> bool:
        return self._client is not None

# Provider Orchestrator — Phase 12

Phase 12 adds real provider adapters while keeping the core provider-agnostic.

## Supported adapters

- `OpenAICompatibleAdapter`: OpenAI, OpenRouter, NVIDIA NIM, Qwen-compatible gateways, local/custom OpenAI-compatible servers.
- `AnthropicAdapter`: Anthropic Messages API.
- `GeminiAdapter`: Google Gemini via `google-genai`.
- `MockProviderAdapter`: deterministic tests only.

## Environment configuration

No secret is stored in source code. Configure only the providers you want to enable.

```env
OPENAI_API_KEY=
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_CHAT_MODEL=gpt-4o-mini
OPENAI_EMBEDDING_MODEL=text-embedding-3-small
OPENAI_VISION_MODEL=gpt-4o

OPENROUTER_API_KEY=
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
OPENROUTER_CHAT_MODEL=
OPENROUTER_EMBEDDING_MODEL=
OPENROUTER_VISION_MODEL=

NVIDIA_API_KEY=
NVIDIA_BASE_URL=https://integrate.api.nvidia.com/v1
NVIDIA_CHAT_MODEL=
NVIDIA_EMBEDDING_MODEL=
NVIDIA_VISION_MODEL=

QWEN_API_KEY=
QWEN_BASE_URL=
QWEN_CHAT_MODEL=qwen-plus
QWEN_EMBEDDING_MODEL=
QWEN_VISION_MODEL=

ANTHROPIC_API_KEY=
ANTHROPIC_CHAT_MODEL=claude-3-5-sonnet-latest

GEMINI_API_KEY=
GEMINI_CHAT_MODEL=gemini-2.5-flash

CUSTOM_LLM_API_KEY=
CUSTOM_LLM_BASE_URL=
CUSTOM_LLM_MODEL=
CUSTOM_EMBEDDING_MODEL=
CUSTOM_VISION_MODEL=
```

## Safety and failover

Provider keys are loaded only from environment variables. The existing registry, capability resolver, health manager, retry logic and circuit breaker remain the source of truth for selection and fallback.

Real external credentials are intentionally not required for the test suite. Integration against a live provider should be run separately with real credentials and explicit network access.

from __future__ import annotations

from dataclasses import dataclass
from backend_v2.vectorstores.base import VectorHit


@dataclass(frozen=True, slots=True)
class RetrievalDecision:
    accepted: list[VectorHit]
    rejected: list[VectorHit]


class RetrievalThreshold:
    def __init__(self, min_score: float = 0.35) -> None:
        self.min_score = min_score

    def apply(self, hits: list[VectorHit]) -> RetrievalDecision:
        accepted = [hit for hit in hits if hit.score >= self.min_score]
        rejected = [hit for hit in hits if hit.score < self.min_score]
        return RetrievalDecision(accepted=accepted, rejected=rejected)

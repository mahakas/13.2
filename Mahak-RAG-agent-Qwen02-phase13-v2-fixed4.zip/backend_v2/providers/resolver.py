from __future__ import annotations

from dataclasses import dataclass

from backend_v2.core.enums import Capability
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.registry import ProviderRegistry, RegisteredProvider


@dataclass(frozen=True, slots=True)
class ProviderSelection:
    provider: RegisteredProvider
    model: str
    score: float
    reason: str


class ProviderResolver:
    """Chooses a healthy compatible provider/model using deterministic scoring."""

    def __init__(self, registry: ProviderRegistry, health: ProviderHealthManager | None = None) -> None:
        self.registry = registry
        self.health = health or ProviderHealthManager()

    @staticmethod
    def _score(provider: RegisteredProvider, model) -> float:
        return (
            model.quality_score * 0.45
            + model.latency_score * 0.20
            + model.cost_score * 0.15
            + (1.0 / max(provider.priority, 1)) * 0.20
        )

    def rank(self, capability: Capability) -> list[ProviderSelection]:
        selections: list[ProviderSelection] = []
        for provider in self.registry.get_candidates(capability):
            if not self.health.is_available(provider.adapter.provider_name, capability):
                continue
            for model in provider.candidate_models(capability):
                selections.append(
                    ProviderSelection(
                        provider=provider,
                        model=model.model,
                        score=self._score(provider, model),
                        reason="healthy capability-compatible model ranked by policy score",
                    )
                )
        return sorted(selections, key=lambda item: item.score, reverse=True)

    def select(self, capability: Capability) -> ProviderSelection:
        ranked = self.rank(capability)
        if not ranked:
            raise RuntimeError(f"No healthy provider supports capability: {capability.value}")
        return ranked[0]

from __future__ import annotations

from pydantic import BaseModel, Field

from backend_v2.core.enums import SourceStatus, SourceType


class SourceCreate(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    source_type: SourceType
    course_id: str
    chapter_id: str | None = None
    lesson_id: str | None = None
    original_url: str | None = None
    storage_key: str | None = None
    metadata_json: dict = Field(default_factory=dict)


class SourceOut(BaseModel):
    id: str
    title: str
    source_type: SourceType
    status: SourceStatus
    course_id: str | None
    chapter_id: str | None
    lesson_id: str | None
    original_url: str | None
    storage_key: str | None

    model_config = {"from_attributes": True}

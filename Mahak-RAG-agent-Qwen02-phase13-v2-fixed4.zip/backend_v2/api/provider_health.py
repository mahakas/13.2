from __future__ import annotations

from fastapi import APIRouter

from backend_v2.core.enums import Capability
from backend_v2.runtime import runtime

router = APIRouter(prefix="/health", tags=["health"])


@router.get("/providers")
def provider_health():
    result = []
    for item in runtime.registry.providers():
        capabilities = [cap.value for cap in Capability if item.adapter.supports(cap)]
        capability_states = {}
        for cap in Capability:
            if cap in {Capability.WEB_SEARCH}:
                continue
            capability_states[cap.value] = runtime.health.state(item.adapter.provider_name, cap).state.value
        result.append({
            "provider": item.adapter.provider_name,
            "enabled": item.enabled and item.profile.enabled,
            "priority": item.priority,
            "capabilities": capabilities,
            "states": capability_states,
        })
    return {"providers": result}

from __future__ import annotations

from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.anthropic import AnthropicAdapter
from backend_v2.providers.adapters.factory import build_external_registry_from_env
from backend_v2.providers.adapters.openai_compatible import OpenAICompatibleAdapter
from backend_v2.providers.contracts import ProviderRequest


class FakeResponse:
    def __init__(self, data, ok=True):
        self._data = data
        self.ok = ok

    def raise_for_status(self):
        if not self.ok:
            raise RuntimeError("http error")

    def json(self):
        return self._data


class FakeSession:
    def __init__(self):
        self.calls = []

    def post(self, url, **kwargs):
        self.calls.append(("POST", url, kwargs))
        if url.endswith("/embeddings"):
            return FakeResponse({"data": [{"embedding": [0.1, 0.2]}, {"embedding": [0.3, 0.4]}]})
        if url.endswith("/messages"):
            return FakeResponse({"content": [{"type": "text", "text": "پاسخ واقعی"}]})
        return FakeResponse({"choices": [{"message": {"content": "پاسخ واقعی"}}]})

    def get(self, url, **kwargs):
        self.calls.append(("GET", url, kwargs))
        return FakeResponse({"data": []})


def test_openai_compatible_chat_and_embedding():
    session = FakeSession()
    adapter = OpenAICompatibleAdapter("openai", "secret", session=session)
    chat = adapter.execute(ProviderRequest(Capability.CHAT, "gpt-test", {"messages": [{"role": "user", "content": "سلام"}]}))
    emb = adapter.execute(ProviderRequest(Capability.EMBEDDING, "embed-test", {"texts": ["a", "b"]}))
    assert chat.output == "پاسخ واقعی"
    assert emb.output == [[0.1, 0.2], [0.3, 0.4]]
    assert len(session.calls) == 2


def test_anthropic_translation_of_system_messages():
    session = FakeSession()
    adapter = AnthropicAdapter("secret", session=session)
    result = adapter.execute(ProviderRequest(Capability.CHAT, "claude-test", {
        "messages": [
            {"role": "system", "content": "فارسی پاسخ بده"},
            {"role": "user", "content": "سلام"},
        ]
    }))
    assert result.output == "پاسخ واقعی"
    body = session.calls[0][2]["json"]
    assert body["system"] == "فارسی پاسخ بده"
    assert body["messages"][0]["role"] == "user"


def test_external_registry_uses_environment_without_secrets_in_code(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("OPENAI_CHAT_MODEL", "test-model")
    registry = build_external_registry_from_env()
    provider = registry.get("openai")
    assert provider is not None
    assert provider.adapter.default_model == "test-model"
    assert provider.profile.candidates(Capability.CHAT)


def test_external_registry_separates_chat_embedding_and_vision_models(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("OPENAI_CHAT_MODEL", "chat-test")
    monkeypatch.setenv("OPENAI_EMBEDDING_MODEL", "embed-test")
    monkeypatch.setenv("OPENAI_VISION_MODEL", "vision-test")
    registry = build_external_registry_from_env()
    provider = registry.get("openai")
    assert provider is not None
    assert [m.model for m in provider.profile.candidates(Capability.CHAT)] == ["chat-test", "vision-test"]
    assert [m.model for m in provider.profile.candidates(Capability.EMBEDDING)] == ["embed-test"]
    assert [m.model for m in provider.profile.candidates(Capability.VISION)] == ["vision-test"]

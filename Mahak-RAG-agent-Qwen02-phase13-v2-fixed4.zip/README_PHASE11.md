# Mahak AI v2 — Phase 11

## Source/Citation Persistence

This phase makes conversations, messages, and source-aware citations persistent in the SQL database.

### New capabilities
- Conversation / message / citation repositories
- Persistent educational chat turns
- Citation persistence with URL, PDF page, and video timestamps
- Conversation history endpoint:
  `GET /api/chat/conversations/{conversation_id}/history`
- API responses remain citation-aware
- Internal metadata is preserved for future source-link resolvers

### Test
```bash
python -m pytest -q tests_v2
python -m compileall -q backend_v2
python -m backend_v2
```
Expected test result in the build environment: `54 passed, 1 skipped`.

The single skip is the optional Chroma integration test when `chromadb` is unavailable.

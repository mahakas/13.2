from __future__ import annotations

from pathlib import Path
from typing import Any

from backend_v2.vectorstores.base import VectorHit, VectorRecord


class ChromaVectorStore:
    """Persistent Chroma implementation of the VectorStore contract."""

    name = "chroma"

    def __init__(self, path: str | Path, *, distance_metric: str = "cosine") -> None:
        try:
            import chromadb
        except ImportError as exc:  # pragma: no cover - depends on environment
            raise RuntimeError("chromadb is required for ChromaVectorStore") from exc

        self.path = str(path)
        self.distance_metric = distance_metric
        self._client = chromadb.PersistentClient(path=self.path)
        self._collections: dict[str, Any] = {}

    def _collection(self, name: str):
        collection = self._collections.get(name)
        if collection is None:
            collection = self._client.get_or_create_collection(
                name=name,
                metadata={"hnsw:space": self.distance_metric},
            )
            self._collections[name] = collection
        return collection

    def upsert(self, records: list[VectorRecord], *, collection: str) -> None:
        if not records:
            return
        dimension = len(records[0].embedding)
        if dimension == 0 or any(len(record.embedding) != dimension for record in records):
            raise ValueError("All embeddings in an upsert batch must have the same non-zero dimension")
        target = self._collection(collection)
        target.upsert(
            ids=[record.id for record in records],
            embeddings=[record.embedding for record in records],
            documents=[record.document for record in records],
            metadatas=[record.metadata for record in records],
        )

    def search(
        self,
        query_embedding: list[float],
        *,
        collection: str,
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
    ) -> list[VectorHit]:
        if not query_embedding:
            return []
        target = self._collection(collection)
        kwargs: dict[str, Any] = {
            "query_embeddings": [query_embedding],
            "n_results": max(1, int(top_k)),
            "include": ["documents", "metadatas", "distances"],
        }
        if filters:
            kwargs["where"] = filters
        result = target.query(**kwargs)
        ids = (result.get("ids") or [[]])[0]
        documents = (result.get("documents") or [[]])[0]
        metadatas = (result.get("metadatas") or [[]])[0]
        distances = (result.get("distances") or [[]])[0]
        hits: list[VectorHit] = []
        for idx, record_id in enumerate(ids):
            distance = float(distances[idx]) if idx < len(distances) else 0.0
            # Chroma returns a distance; convert it into a bounded higher-is-better score.
            score = max(0.0, 1.0 - distance) if self.distance_metric == "cosine" else 1.0 / (1.0 + max(0.0, distance))
            hits.append(
                VectorHit(
                    id=record_id,
                    score=score,
                    document=documents[idx] if idx < len(documents) else "",
                    metadata=metadatas[idx] if idx < len(metadatas) and metadatas[idx] else {},
                )
            )
        return hits

    def delete(self, ids: list[str], *, collection: str) -> None:
        if ids:
            self._collection(collection).delete(ids=ids)

    def health_check(self) -> bool:
        try:
            self._client.heartbeat()
            return True
        except Exception:
            return False

    def count(self, *, collection: str) -> int:
        return int(self._collection(collection).count())

    def reset_for_tests(self, *, collection: str) -> None:
        # Intended only for isolated tests/local development.
        try:
            self._client.delete_collection(collection)
            self._collections.pop(collection, None)
        except Exception:
            pass

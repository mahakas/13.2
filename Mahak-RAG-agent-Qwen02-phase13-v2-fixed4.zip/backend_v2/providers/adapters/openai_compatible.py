from __future__ import annotations

from typing import Any

import requests

from backend_v2.core.enums import Capability
from backend_v2.providers.contracts import ProviderRequest, ProviderResponse


class OpenAICompatibleAdapter:
    """Adapter for OpenAI-compatible chat/embedding/vision APIs."""

    def __init__(self, provider_name: str, api_key: str, *, base_url: str = "https://api.openai.com/v1",
                 default_model: str = "gpt-4o-mini", vision_models: set[str] | None = None,
                 timeout_seconds: float = 60.0, session: requests.Session | None = None) -> None:
        self.provider_name = provider_name
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.default_model = default_model
        self.vision_models = vision_models or set()
        self.timeout_seconds = timeout_seconds
        self.session = session or requests.Session()

    def supports(self, capability: Capability) -> bool:
        if capability is Capability.VISION:
            return bool(self.vision_models)
        return capability in {Capability.CHAT, Capability.EMBEDDING, Capability.STRUCTURED_OUTPUT}

    def execute(self, request: ProviderRequest) -> ProviderResponse:
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = request.payload if isinstance(request.payload, dict) else {"messages": request.payload}
        if request.capability is Capability.EMBEDDING:
            texts = payload.get("texts", [])
            body = {"model": request.model, "input": texts}
            response = self.session.post(f"{self.base_url}/embeddings", headers=headers, json=body, timeout=self.timeout_seconds)
            response.raise_for_status()
            data = response.json()
            vectors = [item["embedding"] for item in data.get("data", [])]
            return ProviderResponse(vectors, self.provider_name, request.model, metadata={"raw": data})

        body: dict[str, Any] = {"model": request.model, "messages": payload.get("messages", [])}
        if payload.get("temperature") is not None:
            body["temperature"] = payload["temperature"]
        if payload.get("max_tokens") is not None:
            body["max_tokens"] = payload["max_tokens"]
        if request.capability is Capability.STRUCTURED_OUTPUT and payload.get("response_format"):
            body["response_format"] = payload["response_format"]
        response = self.session.post(f"{self.base_url}/chat/completions", headers=headers, json=body, timeout=self.timeout_seconds)
        response.raise_for_status()
        data = response.json()
        choice = (data.get("choices") or [{}])[0]
        message = choice.get("message") or {}
        content = message.get("content", "")
        return ProviderResponse(content, self.provider_name, request.model, metadata={"raw": data})

    def health_check(self, capability: Capability | None = None) -> bool:
        if not self.api_key:
            return False
        try:
            response = self.session.get(f"{self.base_url}/models", headers={"Authorization": f"Bearer {self.api_key}"}, timeout=min(self.timeout_seconds, 10.0))
            return response.ok
        except requests.RequestException:
            return False

from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.contracts import ModelProfile
from backend_v2.providers.health import CircuitState, ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.resolver import ProviderResolver


def test_registry_supports_model_profiles():
    registry = ProviderRegistry()
    adapter = MockProviderAdapter("vision-a", {Capability.VISION}, default_model="vision-1")
    registry.register(
        adapter,
        priority=10,
        models=(ModelProfile("vision-1", frozenset({Capability.VISION}), quality_score=0.9),),
    )
    selected = ProviderResolver(registry).select(Capability.VISION)
    assert selected.model == "vision-1"


def test_resolver_skips_open_circuit():
    registry = ProviderRegistry()
    first = MockProviderAdapter("first", {Capability.CHAT})
    second = MockProviderAdapter("second", {Capability.CHAT})
    registry.register(first, priority=1)
    registry.register(second, priority=2)
    health = ProviderHealthManager(failure_threshold=1, cooldown_seconds=60)
    health.record_failure("first", Capability.CHAT, RuntimeError("down"))
    selected = ProviderResolver(registry, health).select(Capability.CHAT)
    assert selected.provider.adapter.provider_name == "second"


def test_orchestrator_falls_back_after_provider_error():
    calls = []

    def bad(_):
        calls.append("bad")
        raise RuntimeError("rate limited")

    def good(_):
        calls.append("good")
        return "answer"

    registry = ProviderRegistry()
    registry.register(MockProviderAdapter("bad", {Capability.CHAT}, bad), priority=1)
    registry.register(MockProviderAdapter("good", {Capability.CHAT}, good), priority=2)
    health = ProviderHealthManager(failure_threshold=1, cooldown_seconds=60)
    result = ProviderOrchestrator(registry, health, max_attempts=2).execute(Capability.CHAT, "hello")
    assert result.response.output == "answer"
    assert calls == ["bad", "good"]
    assert result.attempts == 2


def test_success_closes_half_open_circuit():
    health = ProviderHealthManager(failure_threshold=1, cooldown_seconds=0)
    health.record_failure("x", Capability.EMBEDDING, RuntimeError("down"))
    assert health.state("x", Capability.EMBEDDING).state is CircuitState.OPEN
    assert health.is_available("x", Capability.EMBEDDING)
    assert health.state("x", Capability.EMBEDDING).state is CircuitState.HALF_OPEN
    health.record_success("x", Capability.EMBEDDING)
    assert health.state("x", Capability.EMBEDDING).state is CircuitState.CLOSED

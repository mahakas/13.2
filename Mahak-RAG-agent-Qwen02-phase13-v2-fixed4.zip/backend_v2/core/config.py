"""Version 2 configuration.

This module intentionally contains configuration only. Provider selection,
health, fallback, embeddings and vector-store implementations live elsewhere.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[2]
load_dotenv(BASE_DIR / ".env")


@dataclass(frozen=True, slots=True)
class AppSettings:
    app_name: str = os.getenv("APP_NAME", "Mahak AI")
    environment: str = os.getenv("APP_ENV", "development")
    debug: bool = os.getenv("APP_DEBUG", "false").lower() in {"1", "true", "yes", "on"}
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./mahak_v2.db")
    storage_dir: Path = Path(os.getenv("STORAGE_DIR", str(BASE_DIR / "storage_v2")))
    default_language: str = os.getenv("DEFAULT_LANGUAGE", "fa")
    max_context_messages: int = int(os.getenv("MAX_CONTEXT_MESSAGES", "30"))
    retrieval_top_k: int = int(os.getenv("RETRIEVAL_TOP_K", "12"))
    retrieval_min_score: float = float(os.getenv("RETRIEVAL_MIN_SCORE", "0.35"))
    vector_store_dir: Path = Path(os.getenv("VECTOR_STORE_DIR", str(BASE_DIR / "storage_v2" / "vectors")))


settings = AppSettings()
settings.storage_dir.mkdir(parents=True, exist_ok=True)
settings.vector_store_dir.mkdir(parents=True, exist_ok=True)

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from backend_v2.chat.context import ConversationContext
from backend_v2.chat.planner import QueryPlanner
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.web.search import WebSearchAdapter, WebSearchResult


@dataclass(frozen=True, slots=True)
class FileContext:
    file_id: str
    title: str
    content: str


class FileContextProvider(Protocol):
    def get(self, file_ids: list[str]) -> list[FileContext]: ...


class InMemoryFileContextProvider:
    def __init__(self, files: dict[str, FileContext] | None = None) -> None:
        self.files = files or {}

    def get(self, file_ids: list[str]) -> list[FileContext]:
        return [self.files[file_id] for file_id in file_ids if file_id in self.files]


@dataclass(frozen=True, slots=True)
class GeneralCitation:
    title: str
    url: str | None
    snippet: str


@dataclass(frozen=True, slots=True)
class GeneralChatResponse:
    answer: str
    used_web: bool
    used_files: bool
    citations: tuple[GeneralCitation, ...]
    provider: str | None
    model: str | None
    web_provider: str | None = None


class GeneralChatService:
    """Open-world chat with optional session-file context and web grounding."""

    def __init__(
        self,
        llm_orchestrator: ProviderOrchestrator,
        *,
        web_search: WebSearchAdapter | None = None,
        file_context: FileContextProvider | None = None,
        planner: QueryPlanner | None = None,
    ) -> None:
        self.llm_orchestrator = llm_orchestrator
        self.web_search = web_search
        self.file_context = file_context
        self.planner = planner or QueryPlanner()

    def ask(
        self,
        context: ConversationContext,
        query: str,
        *,
        use_web: bool | None = None,
        top_k_web: int = 5,
    ) -> GeneralChatResponse:
        if context.mode is not ChatMode.GENERAL:
            raise ValueError("GeneralChatService requires general conversation mode")
        clean_query = str(query).strip()
        if not clean_query:
            raise ValueError("Message cannot be empty")

        plan = self.planner.plan(context, has_file=bool(context.session_file_ids))
        if use_web is None:
            use_web = self.planner.should_use_web(clean_query)
        use_web = bool(use_web and plan.allow_web)

        file_items: list[FileContext] = []
        if context.session_file_ids and self.file_context is not None:
            file_items = self.file_context.get(context.session_file_ids)

        web_items: list[WebSearchResult] = []
        if use_web:
            if self.web_search is None or not self.web_search.health_check():
                raise RuntimeError("Web search is unavailable")
            web_items = self.web_search.search(clean_query, top_k=top_k_web)

        prompt = self._build_prompt(context, clean_query, file_items, web_items)
        result = self.llm_orchestrator.execute(
            Capability.CHAT,
            {"messages": prompt, "mode": "general", "use_web": use_web},
            metadata={
                "conversation_id": context.conversation_id,
                "used_web": use_web,
                "file_count": len(file_items),
            },
        )
        answer = str(result.response.output)
        citations = tuple(
            GeneralCitation(item.title, item.url, item.snippet)
            for item in web_items
        )
        context.add_message("user", clean_query)
        context.add_message(
            "assistant",
            answer,
            used_web=use_web,
            used_files=bool(file_items),
            citations=[citation.__dict__ if hasattr(citation, "__dict__") else {"title": citation.title, "url": citation.url} for citation in citations],
        )
        return GeneralChatResponse(
            answer=answer,
            used_web=use_web,
            used_files=bool(file_items),
            citations=citations,
            provider=result.response.provider,
            model=result.response.model,
            web_provider=getattr(self.web_search, "provider_name", None) if web_items else None,
        )

    @staticmethod
    def _build_prompt(
        context: ConversationContext,
        query: str,
        files: list[FileContext],
        web: list[WebSearchResult],
    ) -> list[dict[str, str]]:
        system = (
            "تو دستیار عمومی ماهک هستی. پاسخ را طبیعی و دقیق ارائه کن. "
            "اگر محتوای فایل‌های کاربر در اختیار توست، آن را در اولویت قرار بده. "
            "اگر نتایج وب داده شده‌اند، ادعاهای مربوط به اطلاعات بیرونی را بر اساس همان نتایج پاسخ بده."
        )
        blocks: list[str] = []
        for item in files:
            blocks.append(f"[فایل کاربر: {item.title}]\n{item.content}")
        for index, item in enumerate(web, 1):
            blocks.append(f"[نتیجه وب {index}] {item.title}\nURL: {item.url}\n{item.snippet}")
        context_block = "\n\n".join(blocks) if blocks else "(بدون منبع کمکی)"
        return [
            {"role": "system", "content": system},
            {"role": "system", "content": f"منابع کمکی:\n{context_block}"},
            {"role": "user", "content": query},
        ]
